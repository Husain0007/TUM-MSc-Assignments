"""Define tests, sanity checks, and evaluation"""
from .eval_utils import save_pickle